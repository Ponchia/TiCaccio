import { Component, ViewChild, ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams, Platform } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
// import { ActionSheet, ActionSheetOptions } from '@ionic-native/action-sheet';

import { ActionSheetController } from 'ionic-angular'

// import { Storage } from '@ionic/storage';

import * as leaflet from 'leaflet';
import 'leaflet-easybutton';

// import 'leaflet-tilelayer-cordova';
// import 'leaflet-offline'; 


// declare var cordova;

//import leaflet from 'leaflet-easybutton';

// require('node_modules/leaflet-easybutton/src/easy-button.d.ts');

@IonicPage()
@Component({
  selector: 'page-map',
  templateUrl: 'map.html',
})
export class MapPage {

  @ViewChild('map') mapContainer: ElementRef;
  map: any;
  alert: any;
  lat: any;
  lng: any;

  hunting_area: any;

  deer: any;
  boar: any;

  selected: any;

  markers: any;

  lastClick: any;

  base: any;

  current: any;

  constructor(public navCtrl: NavController,
    public navParams: NavParams, private geolocation: Geolocation,
    public actionSheetCtrl: ActionSheetController, platform: Platform) {
    this.deer = leaflet.icon({
      iconUrl: '../../assets/icon/Marker/Deer.ico',

      iconSize: [20, 20], // size of the icon
      iconAnchor: [0, 15], // point of the icon which will correspond to marker's location
      popupAnchor: [10, -10] // point from which the popup should open relative to the iconAnchor
    });

    this.boar = leaflet.icon({
      iconUrl: '../../assets/icon/Marker/Boar.svg',

      iconSize: [20, 20], // size of the icon
      iconAnchor: [0, 15], // point of the icon which will correspond to marker's location
      popupAnchor: [0, 0] // point from which the popup should open relative to the iconAnchor
    });

    this.selected = this.deer;

    platform.ready().then(() => {
      // alert((<any>window).mauron85-background-geolocation);
    });

    this.markers = new Array();
    this.hunting_area = new Array();

    

    
  }

  ionViewDidLoad() {
    let input_file = [
    //   {
    //   "type": "Feature",
    //   "properties": { "animal": "Deer" },
    //   "geometry": {
    //     "type": "Polygon",
    //     "coordinates": [[
    //       [8.98737967014313, 45.86880711041877],
    //       [8.987900018692018, 45.86901254955251,],
    //       [8.987739086151125, 45.86924786980906],
    //       [8.987084627151491, 45.8690760487675]
    //     ]]
    //   }
    // },
    {
      "type": "Feature",
      "properties": { "animal": "Deer" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[
          [45.86880711041877, 8.98737967014313],
          [45.86901254955251,8.987900018692018],
          [45.86924786980906, 8.987739086151125],
          [45.8690760487675, 8.987084627151491]
        ]]
      }
    }
    // ,{
    //   "type": "Feature",
    //   "properties": { "animal": "Boar" },
    //   "geometry": {
    //     "type": "Polygon",
    //     "coordinates": [[
    //       [8.986687660217287, 45.869692360908786],
    //       [8.986794948577883, 45.86944583687232],
    //       [8.987524509429933, 45.86966994967794]
    //     ]]
    //   }
    // }
  ];

    this.geolocation.getCurrentPosition().then((resp) => {
      this.map = leaflet.map("map").fitWorld();
      this.loadmap(resp.coords.latitude, resp.coords.longitude);
      this.lat = resp.coords.latitude;
      this.lng = resp.coords.longitude;
    }).catch((error) => {
      console.log('Error getting location', error);
    });

    this.loadareas(input_file);
    this.current = "";
  }

  loadmap(lat, lon) {
    this.map.setView(leaflet.latLng(lat, lon), 20);

    leaflet.tileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      subdomains: ['a', 'b', 'c']
    }).addTo(this.map);


    this.hunting_area.forEach((e) => {
      leaflet.polygon(e.getLatLngs()[0], e.options).addTo(this.map);
     });

    /* VERY FRICKING IMPORTANT */
    this.map.on('click', (e) => { this.onMapClick(e) });

    let btn_marker = '<a class="leaflet-control-zoom-in" href="#" title="Zoom in" role="button" aria-label="Zoom in">+</a>'


    leaflet.easyButton('&starf;', () => { this.presentActionSheet() }).addTo(this.map);
  }

  loadareas(input_geoJSON) {
    let areas = new Array();
    input_geoJSON.forEach(function (state) {
      let polygon = leaflet.polygon(state.geometry.coordinates, {
        weight: 1,
        fillOpacity: 0.7,
        color: 'red',
        dashArray: '3'
      });
      areas.push(polygon);
    });

    this.hunting_area = areas;
    // console.log(this.hunting_area);
  }

  isMarkerInsidePolygon(marker, poly) {
    let polyPoints = poly.getLatLngs()[0];
    let x = marker.getLatLng().lat, y = marker.getLatLng().lng;

    let inside = false;
    for (let i = 0, j = polyPoints.length - 1; i < polyPoints.length; j = i++) {
      let xi = polyPoints[i].lat, yi = polyPoints[i].lng;
      let xj = polyPoints[j].lat, yj = polyPoints[j].lng;

      let intersect = ((yi > y) != (yj > y))
        && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
      if (intersect) inside = !inside;
    }

    return inside;
  };


  presentActionSheet() {
    let actionSheet = this.actionSheetCtrl.create({
      title: 'Modify your marker',
      buttons: [
        {
          text: 'Deer',
          // role: 'destructive',
          handler: () => {
            console.log('deer');
            this.selected = this.deer;
          }
        },
        {
          text: 'Boar',
          handler: () => {
            console.log('Archive clicked');
            this.selected = this.boar;
          }
        },
        {
          text: 'Normal',
          handler: () => {
            console.log('Archive clicked');
          }
        },
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });

    actionSheet.present();
  }

  onMapClick(e) {
    let marker = leaflet.marker(e.latlng, { icon: this.selected }).addTo(this.map);
    if (this.markers.length == 0) {
      this.markers.push(marker);
      console.log(this.markers);
    } else if (this.markers[this.markers.length - 1]._latlng.lat != e.latlng.lat &&
      this.markers[this.markers.length - 1]._latlng.lng != e.latlng.lng) { //instead of using the exact point use the area of a circle big as the icon
      marker.bindPopup('test');
      this.markers.push(marker);
      console.log(this.isMarkerInsidePolygon(marker, this.hunting_area[0]));
    }
  };

  cancelMarker(id) {
    console.log(id);
  }
}